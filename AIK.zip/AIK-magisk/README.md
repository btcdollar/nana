# <u>Magiskboot based Android Image Kitchen</u>

<pre>
   _     _____                                 _     _
  /_\    \_   \/\ /\     _ __ ___   __ _  __ _(_)___| | __
 //_\\    / /\/ //_/____| '_ ` _ \ / _` |/ _` | / __| |/ /
/  _  \/\/ /_/ __ \_____| | | | | | (_| | (_| | \__ \   < 
\_/ \_/\____/\/  \/     |_| |_| |_|\__,_|\__, |_|___/_|\_\
                                         |___/ by fossfrog
twitter/git: shubhamvis98

Usage:
        ./unpackimg android_boot.img       #unpack boot.img
        ./repackimg                        #repack new-boot.img
        ./cleanup                          #clean workspace

</pre>
>**Source:**  
Magisk
